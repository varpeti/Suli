package ml.varpeti.hf04

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat.startActivity
import android.util.Log
import android.view.View
import android.widget.EditText
import com.google.firebase.FirebaseApp
import com.google.firebase.database.*
import java.util.*
import kotlin.collections.HashMap


class MainActivity : AppCompatActivity()
{
    lateinit var database : FirebaseDatabase
    lateinit var reference : DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState) //Visszatölti elforgatás után
        setContentView(R.layout.activity_main)

        //Sehol nincs megemlítve, THX StackOwerflow <3
        FirebaseApp.initializeApp(this)

        database = FirebaseDatabase.getInstance()
        reference = database.getReference("HF04")
    }

    class FirebaseListener(val uuid : UUID, val context : Context) : ValueEventListener
    {
        override fun onDataChange(p0: DataSnapshot)
        {

            //Log.i("|||onDataChange", p0.toString())
            val users = p0.value as HashMap<String, Any>

            if (users.containsKey(uuid.toString())) // .addOnSuccessListener helyett
            {

                //val user = p0.getValue(User::class.java)!! //Ez nem fut le soha
                //val user = users[uuid.toString()] as User //Ez elhasal

                /* // Ez a kód működik: ki tudom így nyerni a usert. De nem kell ide.
                val user = User(uuid, users[uuid.toString()].toString()) //Vigyázz Fekete Mágia!

                Log.i("|||user:", "${user.name} | ${user.email} | ${user.description}")
                */

                val intent = Intent(context,ShowUsersActivity::class.java)
                intent.putExtra("users",p0.toString()) //Igen, elküldöm a teljes adatbázist -.-
                startActivity(context,intent,null)

            } else {
                Log.w("|||FirebaseListener-onDataChange", "not contains the key")
            }
        }

        override fun onCancelled(p0: DatabaseError)
        {
            Log.w("|||FirebaseListener",p0.toString())
        }

    }

    fun sendUserData()
    {
        try
        {
            val usersRef = reference.child("users")
            val users = HashMap<String,Any>()

            val name = findViewById<EditText>(R.id.name)
            val email = findViewById<EditText>(R.id.email)
            val description = findViewById<EditText>(R.id.description)

            val user = User(name.text.toString(), email.text.toString(), description.text.toString())
            users.put(user.uuid.toString(),user)

            usersRef.addListenerForSingleValueEvent(FirebaseListener(user.uuid,this))

            usersRef.updateChildren(users)/*.addOnSuccessListener{
                val intent = Intent(this@MainActivity,ShowUsersActivity::class.java)
                startActivity(intent)
            }*/ // Nem megy, részleteket lásd ShowUsersActivity-ban.

            Log.i("|||sendUserData","Send")
        }
        catch (e : Exception) //TODO better exception handling
        {
            Log.i("|||sendUserData","Smting went wrong...")

            // Miután elindítottam a programot és kikapcsoltam két küldés között a netet azután se hasalt el.
            // Ha nem lövöm ki a programot, amint nethez jut elküldi a csomagokat, nem kell a programnak előtérben lennie.
        }
    }

    fun onSend(v : View)
    {
        // Külön szállra
        Thread(Runnable(function = {sendUserData()}), "sendUserDataAsync").start()
    }
}
