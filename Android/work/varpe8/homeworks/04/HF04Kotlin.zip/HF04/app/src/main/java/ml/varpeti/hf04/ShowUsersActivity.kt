package ml.varpeti.hf04

import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.widget.TextView


/* // Kiszedve mert sehogy se sikerült elérni az adatbázis, se írásra se olvasásra
import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.database.*

class ShowUsersActivity : AppCompatActivity()
{
    lateinit var database : FirebaseDatabase
    lateinit var reference : DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?)
    {
        super.onCreate(savedInstanceState, persistentState)
        setContentView(R.layout.activty_show_users)

        //FirebaseApp.initializeApp(this)

        database = FirebaseDatabase.getInstance()
        reference = database.getReference("HF04")
        val usersRef = reference.child("users")

        //usersRef.addValueEventListener(ShowUsers())
        val users = HashMap<String,Any>()

        val name = "000"
        val email = "000"
        val description = "222"
        val user = User(name, email, description)
        users.put("000",user)
        usersRef.push().setValue("asdcdcede")
        usersRef.updateChildren(users)

        //usersRef.setValue("ALMÁSPITE")

    }

    inner class ShowUsers : ValueEventListener
    {
        override fun onDataChange(p0: DataSnapshot)
        {
            Log.i("|||fe","start")
            /*val users = p0.value as HashMap<String, Any>

            users.forEach { k, v ->
                val user = v as User
                Log.i("|||fe","${user.name}")
            }*/
        }

        override fun onCancelled(p0: DatabaseError)
        {
            Log.w("|||ShowUsers","err")
        }
    }
}*/

class ShowUsersActivity : AppCompatActivity()
{

    var users : String? = null

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?)
    {
        Log.i("|||onCreate","-")
        super.onCreate(savedInstanceState, persistentState)
        setContentView(R.layout.activty_show_users)

        /*
        val rv = findViewById<RecyclerView>(R.id.RV)

        val tw = TextView(this)
        tw.text="ALMA"
        rv.addView(tw)

        //Lekérjük a teljes adatbázist -.-
        val extras = intent.extras ?: return
        users = extras.getString("users")

        Thread(Runnable(function = {showUsers()}), "ShowUsersAsync").start() */
    }

    private fun showUsers()
    {
        // Igen, egy kis regex fekete mágia
        Log.i("|||ShowUsers",users!!)
    }
}
