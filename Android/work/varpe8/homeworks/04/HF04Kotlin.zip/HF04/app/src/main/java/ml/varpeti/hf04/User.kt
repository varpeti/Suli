package ml.varpeti.hf04

import java.util.*

class User(var name: String, var email: String, var description: String)
{
    var uuid = UUID.randomUUID()

    //Kell hogy bele tudja írni a firebase
    constructor() : this("", "", "") {}

    // BLACK MAGIC ALERT!!!
    // IMPORTANT:
    // IF YOU ACCIDENTALLY READ THIS, YOU HAVE TO WASH YOUR EYES!
    constructor(uuid : UUID, s : String) : this()
    {
        val namer        = Regex("name[=]([^,}]*)[,}]")
        val emailr       = Regex("email[=]([^,}]*)[,}]")
        val descriptionr = Regex("description[=]([^,}]*)[,}]", setOf(RegexOption.DOT_MATCHES_ALL))

        val rname        = namer.find(s)
        val remail       = emailr.find(s)
        val rdescription = descriptionr.find(s)

        this.uuid = uuid
        if (rname != null)        this.name = rname.destructured.component1()
        if (remail != null)       this.email = remail.destructured.component1()
        if (rdescription != null) this.description = rdescription.destructured.component1()
    }
}